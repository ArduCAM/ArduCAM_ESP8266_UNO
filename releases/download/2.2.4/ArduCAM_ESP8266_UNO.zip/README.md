# ArduCAM_ESP8266_UNO
Please use josn board manager script from http://www.arducam.com/downloads/ESP8266_UNO/package_ArduCAM_index.json to download ESP8266 UNO board support files. <br>

# Pin Source Definition

## ArduCAM ESP8266 UNO board
![Alt text](https://github.com/ArduCAM/ArduCAM_ESP8266_UNO/blob/master/doc/UNO.png)

## ArduCAM ESP8266 Nano V2 board
![Alt text](https://github.com/ArduCAM/ArduCAM_ESP8266_UNO/blob/master/doc/Nano_V2.png)

# ArduCAM ESP8266 UNO MINI Camera Demo Tutorial
[![IMAGE ALT TEXT](https://github.com/UCTRONICS/pic/blob/master/Arducam_ESP8266_Camera.jpeg)](https://youtu.be/n1dDGNpbxGM  "AArduCAM ESP8266 UNO MINI Camera Demo Tutorial")
